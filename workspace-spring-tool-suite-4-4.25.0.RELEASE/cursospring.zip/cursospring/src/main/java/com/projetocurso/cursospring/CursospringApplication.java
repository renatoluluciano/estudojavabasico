package com.projetocurso.cursospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursospringApplication.class, args);
	}

}
